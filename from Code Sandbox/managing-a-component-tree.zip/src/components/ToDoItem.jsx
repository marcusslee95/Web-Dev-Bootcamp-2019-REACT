import React, { useState } from "react";

//implementing delete item in items array in parent component functionality 
function ToDoItem(props){

  
      
  
    // return <li style={{textDecoration: "line-through"}}> {props.text} </li>
  
  return <li 
  onClick={function(){
    props.onChecked(props.id);
  }}> {props.text} </li>
  }

  // Implementing strike through functionality 
// function ToDoItem(props){
// const [clicked, setClicked] = useState(false);
//   // console.log(props.text);
//   function handleClick(){
//     // setClicked(true);
//     setClicked(function(prevValue){
//       return !prevValue;
//     });
//   }
//   // return <li style={{textDecoration: "line-through"}}> {props.text} </li>

// return <li onClick={handleClick} style={{textDecoration:clicked ? "line-through" : "none"}}> {props.text} </li>
// }

export default ToDoItem;