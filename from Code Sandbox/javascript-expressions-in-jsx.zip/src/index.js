import React from "react";
import ReactDOM from "react-dom";

let luckyNum = 7;
let fName = "Marcus";
let lName = "Lee";
ReactDOM.render(
<div>
  <h1>Hello {fName + " " + lName}!</h1>
  <p>This is a number {Math.random() * luckyNum}</p>
  </div>, 
  document.getElementById("root"));
