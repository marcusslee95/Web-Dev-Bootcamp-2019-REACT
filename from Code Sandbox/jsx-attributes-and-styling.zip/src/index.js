import React from "react";
import ReactDOM from "react-dom";

let randoImage = "https://picsum.photos/200/300";

// console.log(randoImage +"?grayscale");
ReactDOM.render(
  <div>
    <h1 className="heading" contentEditable="true" spellCheck="false">My Favourite Foods</h1>
    <img alt="random" src={randoImage + "?grayscale"}></img>
    <img
className="food-img"
      alt="img1"
      src="https://hips.hearstapps.com/hmg-prod.s3.amazonaws.com/images/delish-190621-air-fryer-bacon-0035-landscape-pf-1567632709.jpg?crop=0.645xw:0.967xh;0.170xw,0.0204xh&resize=480:*"
    />
    <img
    className="food-img"
    alt="img2"
      src="https://images-na.ssl-images-amazon.com/images/I/71lNrnbMXsL._SL1200_.jpg"
    />
    <img
    className="food-img"
    alt="img3"
      src="https://www.errenskitchen.com/wp-content/uploads/2014/04/quick-and-easy-chinese-noodle-soup3-1.jpg"
    />
  </div>,
  document.getElementById("root")
);
