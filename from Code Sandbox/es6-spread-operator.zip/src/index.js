import React from "react";
import ReactDOM from "react-dom";
import App from "./components/App";

ReactDOM.render(<App />, document.getElementById("root"));


//Playing with spread operator
// let curry = [1,2,3]; 
// let curry2 = [...curry, 4,5,6]; 
// console.log(curry2)

// let obj1 = {yoda: "baby", kenobi: "obi"};
// let obj2 = {
//   ...obj1,
//   yoda: "oldy"};
// console.log(obj2);
