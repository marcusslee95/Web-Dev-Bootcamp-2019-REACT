import React, { useState } from "react";

function App() {
  let [fullName, setFullName] = useState({
    fName: "",
    lName: ""
  });
  
function handleSubmit(event){
  event.preventDefault();
}

function handleChange(event){
  let newValue = event.target.value;
  if (event.target.name === "fName"){
  // setFullName({fName: event.target.value});
  // setFullName({fName: event.target.value, lName: prev.lName}); <- Failed attempt
  setFullName((prev) => {
    // console.log(prev);
    return {
      fName: newValue,
      lName: prev.lName
    }
  });
}
 else if (event.target.name === "lName") {
    // setFullName({lName: event.target.value});
    setFullName((prev) => {
      // console.log(prev);
      return {
        fName: prev.fName,
        lName: newValue
      }
    });
  }
}
return (
    <div className="container">
      <h1>Hello {fullName.fName} {fullName.lName} </h1>
      <form onSubmit={handleSubmit}>
        <input onChange={handleChange} name="fName" placeholder="First Name" />
        <input onChange={handleChange} name="lName" placeholder="Last Name" />
        <button>Submit</button>
      </form>
    </div>
  );
}

// function App() {
//   let [fName, setFName] = useState("");
//   let [lName, setLName] = useState("");
  
// function handleFirstChange(event){
//   setFName(event.target.value);
// }

// function handleLastChange(event){
//   setLName(event.target.value);
// }

// function handleSubmit(event){
//   event.preventDefault();
// }

// return (
//     <div className="container">
//       <h1>Hello {fName} {lName} </h1>
//       <form onSubmit={handleSubmit}>
//         <input onChange={handleFirstChange} name="fName" placeholder="First Name" value={fName}/>
//         <input onChange={handleLastChange} name="lName" placeholder="Last Name" value={lName}/>
//         <button>Submit</button>
//       </form>
//     </div>
//   );
// }

export default App;
