// CHALLENGE: uncomment the code below and see the car stats rendered
import React from "react";
import ReactDOM from "react-dom";
import cars from "./practice";
import animals from "./data";



//MY CODE: STARTS
//Practice code: START
console.log(animals);
const [cat, dog] = animals;
const {name, sound, feedingRequirements: {food, water}} = cat
console.log(name, sound, food, water);
//Practice code: END

//1st Go Around: START
// let tesla = cars[1];
// let teslaTopSpeed = tesla.speedStats.topSpeed;
// let teslaTopColour= tesla.coloursByPopularity[0];
// console.log(tesla);

// let honda = cars[0];
// let hondaTopSpeed = honda.speedStats.topSpeed;
// let hondaTopColour= honda.coloursByPopularity[0];
//1st Go Around: END

//2nd Go Around aka. using destructuring: START
// eg1 of destructuring 
const [honda, tesla] = cars; 
// console.log(tesla);
// eg2 of destructuring 
const {speedStats: {topSpeed: teslaTopSpeed}, coloursByPopularity:[teslaTopColour]} = tesla; 
const {speedStats: {topSpeed: hondaTopSpeed}, coloursByPopularity:[hondaTopColour]} = honda; 
//2nd Go Around: END

// {
//   model: "Tesla Model 3",
//   coloursByPopularity: ["red", "white"],
//   speedStats: {
//     topSpeed: 150,
//     zeroToSixty: 3.2
//   }
// }

//MY CODE: ENDS
ReactDOM.render(
  <table>
    <tr>
      <th>Brand</th>
      <th>Top Speed</th>
    </tr>
    <tr>
      <td>{tesla.model}</td>
      <td>{teslaTopSpeed}</td>
      <td>{teslaTopColour}</td>
    </tr>
    <tr>
      <td>{honda.model}</td>
      <td>{hondaTopSpeed}</td>
      <td>{hondaTopColour}</td>
    </tr>
  </table>,
  document.getElementById("root")
);
