import React from "react";
import ReactDOM from "react-dom";


let obj = {
  color: "red",
  fontSize: "30px",
  border: "1px solid black"
  };

  obj.color = "blue";

ReactDOM.render(<h1 style={obj}>Hello World!</h1>, document.getElementById("root"));
