import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import Note from "./Note";
import notes from "../notes";

// function createNotes(stuffToCreateNotes){
//   return <Note key={stuffToCreateNotes.key}
//   title={stuffToCreateNotes.title}
//   content={stuffToCreateNotes.content}/>
// }
function App() {
  return (
    <div>
      <Header />
      {notes.map(stuffToCreateNotes => 
 <Note key={stuffToCreateNotes.key}
  title={stuffToCreateNotes.title}
  content={stuffToCreateNotes.content}/>
)}
      {/* {notes.map(someFunctionThatCreatesNoteComponents)} */}
      {/* <Note title={notes[0].title} content={notes[0].content}/>
      <Note title="" content=""/>
      <Note title="" content=""/> */}
      <Footer />
    </div>
  );
}

export default App;
