import React from "react";

function Form(props) {
  return (
    <form className="form">     
 <input type="text" placeholder="Username" />
 <input type="password" placeholder="Password" /> 
 {/* {props.registeredOrNah ? null : <input type="password" placeholder="Confirm Password" />} */}
 {!props.registeredOrNah && <input type="password" placeholder="Confirm Password" />}
 <button type="submit">{props.registeredOrNah ? "Login" : "Register"}</button>
    </form>
  );
}

// {!props.registeredOrNah ? <input type="password" placeholder="Confirm Password" />
//  <button type="submit">Register</button> : <input type="text" placeholder="Username" />
//  <input type="password" placeholder="Password" />
// }

// function Form(props) {
//   return (
//     <form className="form">     
//  <input type="text" placeholder="Username" />
//  <input type="password" placeholder="Password" /> 
//  <input type="password" placeholder="Confirm Password" />
//  <button type="submit">Register</button>
//     </form>
//   );
// }


export default Form;
