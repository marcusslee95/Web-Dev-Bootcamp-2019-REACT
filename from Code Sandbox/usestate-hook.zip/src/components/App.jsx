import React from "react";

function App() {
  // let count = 0;
  // let state = React.useState(3242342);
  let [count, setCount] = React.useState(0); //initialized a state variable 

  function increment() {
    // count++; 
    setCount(count + 1); // change state variable here. If it changes there'll be changes on UI
  }
  function decrement() {
    setCount(count - 1);
  }
  return ( <div className="container">
  <h1>{count}</h1> 
  <button onClick={increment}>+</button>
  <button onClick={decrement}>-</button>
</div>)
}


export default App;
