import React from "react";
import Input from "./Input";

function Login(){
  return <form className="form">
    <div>
    <Input type="text" placeholder="Username"/>
    <Input type="password" placeholder="Password"/>
    <button type="submit">Login</button>
    </div>
  
    </form>
  } 

  export default Login;