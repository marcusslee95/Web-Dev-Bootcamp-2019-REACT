//Create a react app from scratch.
//It should display a h1 heading.
//It should display an unordered list (bullet points).
//It should contain 3 list elements.

//enable usage of react in this file 
import React from "react"
import ReactDOM from "react-dom"

ReactDOM.render(
<div>
  <h1>Hi Vina</h1><ul><li>We Fight</li><li>But I still love you</li><li>That's true</li></ul>
  </div>, 
  document.getElementById("root")); 
