import React from "react";


function App() {
  // let time = new Date().toLocaleTimeString();
// console.log(time);
let [time, setTime] = React.useState(new Date().toLocaleTimeString());
setInterval(updateTime, 1000);

function updateTime(){
  // time = new Date().toLocaleTimeString();
  // console.log(time);
  return setTime(new Date().toLocaleTimeString());
}
  return (
    <div className="container">
      <h1>{time}</h1>
      <button onClick={updateTime} >Get Time</button>
    </div>
  );
}

// function App() {
//   return (
//     <div className="container">
//       <h1>TIME</h1>
//       <button>Get Time</button>
//     </div>
//   );
// }


export default App;
