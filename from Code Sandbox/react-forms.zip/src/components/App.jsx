import React, {useState} from "react";

function App() {
  const [name, setName] = useState("");
  const [heading, setHeading] = useState("");
  function handleChange(event){
// console.log("changed"); 
// console.log(event.target.placeholder);
// console.log(event.target.type);
console.log(event.target.value);
setName(event.target.value);
}

function handleClick(event){
  setHeading(name);
  event.preventDefault();
}
  

    return (
    <div className="container">
      <h1>Hello {heading} </h1>
      <form onSubmit={handleClick}>
      <input 
      onChange={handleChange}
      type="text" 
      placeholder="What's your name?" 
      value={name}/>
      <button
      onClick={handleClick}>
        Submit
        </button>
        </form>
    </div>
  );
}

// return (
//   <div className="container">
//     <h1>Hello </h1>
//     <input 
//     onChange={handleChange}
//     type="text" placeholder="What's your name?" />
//     <button>Submit</button>
//   </div>
// );

export default App;
