import React from "react";
import Heading from "./Heading";

function App(){
  return <div>
    <Heading></Heading>
  </div>;
}

export default App;