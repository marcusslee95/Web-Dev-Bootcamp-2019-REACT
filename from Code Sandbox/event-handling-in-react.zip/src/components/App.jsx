import React, { useState } from "react";



function App() {
  const [heading, setHeading] = useState("Hello!");
  const [isMousedOver, setIsMousedOver] = useState(false);
  function handleClick() {
    // console.log("clicked");
    setHeading("Clicked");
  }
  
  function handleMouseOver() {
    // console.log("moused over");
    setIsMousedOver(true);
  }

  function handleMouseOut(){
    setIsMousedOver(false);
  }
  return (
    <div className="container">
      <h1>{heading}</h1>
      <input type="text" placeholder="What's your name?" />
      <button style={{backgroundColor: isMousedOver ? "black" : "white"}} 
      onClick={handleClick} 
      onMouseOver={handleMouseOver}
      onMouseOut={handleMouseOut}>Submit</button>
    </div>
  );
}

export default App;
