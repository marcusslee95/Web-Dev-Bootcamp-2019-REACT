import React, {useState} from "react";

function App() {
  const [toDoList, setToDoList] = useState([]);
  const [valueTracker, setValueTracker] = useState("");
  function handleChange(event){
    const newVal = event.target.value
    setValueTracker(newVal);
  }
  
  function handleClick(event){
    // const newValue = event.target.value;
    const newValue = valueTracker;
    // console.log(newValue);
    // console.log(toDoList);
    setToDoList((prev) => {
      return [
        ...prev, 
        newValue
      ];
    });

    setValueTracker(""); //just resetting the Value after added it 
  }
  return (
    <div className="container">
      <div className="heading">
        <h1>To-Do List</h1>
      </div>
      <div className="form">
        <input onChange={handleChange} type="text" value={valueTracker}/>
        <button onClick={handleClick}>
          <span>Add</span>
        </button>
      </div>
      <div>
        <ul>
        {toDoList.map((todoItem) => {return <li>{todoItem}</li>;})}
        </ul>
      </div>
    </div>
  );
}

export default App;
