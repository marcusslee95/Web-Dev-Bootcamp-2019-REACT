import React, { useState } from "react";
import AddIcon from '@material-ui/icons/Add';
import { Fab } from '@material-ui/core';
import { Zoom } from '@material-ui/core';

function CreateArea(props) {
  const [note, setNote] = useState({
    title: "",
    content: ""
  });
  const [isContentClicked, SetIsContentClicked] = useState(false);
  //if content is not clicked wnat to 1. not have the title input element 2. reduce row size of content input element 3. not have the button 

  function handleChange(event) {
    const { name, value } = event.target;

    setNote(prevNote => {
      return {
        ...prevNote,
        [name]: value
      };
    });
  }

  function submitNote(event) {
    event.preventDefault();
    props.onAdd(note);
    setNote({
      title: "",
      content: ""
    });

  }

  function clicked(){
    SetIsContentClicked(true);
  }

  return (
    <div>
      <form className="create-note">
      {isContentClicked ? <input
    name="title"
    onChange={handleChange}
    value={note.title}
    placeholder="Title"
  /> : null}
        <textarea
          name="content"
          onClick={clicked}
          onChange={handleChange}
          value={note.content}
          placeholder="Take a note..."
          rows={isContentClicked ? "3" : "1"}
        />
        <Zoom in={isContentClicked ? true: false}>
        <Fab onClick={submitNote}><AddIcon /></Fab>
        </Zoom>
      </form>
    </div>
  );

  // return (
  //   <div>
  //     <form className="create-note">
  //       <input
  //         name="title"
  //         onChange={handleChange}
  //         value={note.title}
  //         placeholder="Title"
  //       />
  //       <textarea
  //         name="content"
  //         onChange={handleChange}
  //         value={note.content}
  //         placeholder="Take a note..."
  //         rows="3"
  //       />
  //       <Zoom in={true}>
  //       <Fab onClick={submitNote}><AddIcon /></Fab>
  //       </Zoom>
  //     </form>
  //   </div>
  // );
}

// function CreateArea(props) {
//   const [note, setNote] = useState({
//     title: "",
//     content: ""
//   });

//   function handleChange(event) {
//     const { name, value } = event.target;

//     setNote(prevNote => {
//       return {
//         ...prevNote,
//         [name]: value
//       };
//     });
//   }

//   function submitNote(event) {
//     props.onAdd(note);
//     setNote({
//       title: "",
//       content: ""
//     });
//     event.preventDefault();
//   }

//   return (
//     <div>
//       <form className="create-note">
//         <input
//           name="title"
//           onChange={handleChange}
//           value={note.title}
//           placeholder="Title"
//         />
//         <textarea
//           name="content"
//           onChange={handleChange}
//           value={note.content}
//           placeholder="Take a note..."
//           rows="3"
//         />
//         <button onClick={submitNote}>Add</button>
//       </form>
//     </div>
//   );
// }

export default CreateArea;
