import React, { useState } from "react";

function App() {
  const [contact, setContact] = useState({
    fName: "",
    lName: "",
    email: ""
  });

  function handleChange(event){
    let {value} = event.target; //getting values of event cuz can't have event variable in the state var setter method 

    //update relevant values; 
    if (event.target.name === "fName"){
      setContact((prevState) => {
        return {fName: value,
        lName: prevState.lName,
      email: prevState.email}
      });
    } else if (event.target.name === "lName"){
      setContact((prevState) => {
        return {fName: prevState.fName,
        lName: value,
      email: prevState.email}
      });
    } else if (event.target.name === "email"){
      setContact((prevState) => {
        return {fName: prevState.fName,
        lName: prevState.lName,
      email:value}
      });
    }
  }

  function handleSubmit(event){
    event.preventDefault();
  }
  return (
    <div className="container">
      <h1>
        Hello {contact.fName} {contact.lName}
      </h1>
      <p>{contact.email}</p>
      <form onSubmit={handleSubmit}>
        <input onChange={handleChange} name="fName" placeholder="First Name" />
        <input onChange={handleChange} name="lName" placeholder="Last Name" />
        <input onChange={handleChange}  name="email" placeholder="Email" />
        <button>Submit</button>
      </form>
    </div>
  );
}

// function App() {
//   const [contact, setContact] = useState({
//     fName: "",
//     lName: "",
//     email: ""
//   });

//   return (
//     <div className="container">
//       <h1>
//         Hello {contact.fName} {contact.lName}
//       </h1>
//       <p>{contact.email}</p>
//       <form>
//         <input name="fName" placeholder="First Name" />
//         <input name="lName" placeholder="Last Name" />
//         <input name="email" placeholder="Email" />
//         <button>Submit</button>
//       </form>
//     </div>
//   );
// }


export default App;
