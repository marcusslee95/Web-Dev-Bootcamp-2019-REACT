import React, { useState } from "react";

function CreateArea(props) {
  const [note, setNote] = useState({
    title: "",
    content: ""
  });

  function handleChange(event){
    const {name, value} = event.target; // <- this is like getting event.target.name and event.target.value in one line 

    //update note state variable -> which you can do by keeping what it was before and just changing the k-v pair that got changed
    setNote(function(prev){ //making new value return of a function allows you to get the previous state of the sv
      return {
        ...prev, 
        [name]: value // [] is because otherwise computer sees name as the string "name"
      };
    });
  }
  function submitNote(event){
    event.preventDefault(); // prevent default behavior of when submit input stuff in a form i.e. with clicking button - whole think refreshes along with values we're keepign track of
      props.functionToPassInFromParent(note);
    setNote({
      title: "",
      content: ""
    });
  }

  return (
    <div>
      <form>
        <input 
        onChange={handleChange}
        name="title" 
        placeholder="Title" 
        value={note.title} // Just showing that doing this thing of tying the input value to state variable is not necessary functionality wise but just a best practice to make sure everything's drawing from state variable
        />
        <textarea 
        onChange={handleChange}
        name="content" placeholder="Take a note..." rows="3" 
        value={note.content}
        />
        <button
        onClick={
          submitNote
        }>
          Add</button>
      </form>
    </div>
  );
}

// function CreateArea(props) {
//   return (
//     <div>
//       <form>
//         <input  
//         onChange={function(){
//           props.inputChangeHandling(event);
//         }}
//         name="title" 
//         placeholder="Title" />
//         <textarea
//         onChange={function(){
//           props.inputChangeHandling(event);
//         }}
//          name="content" 
//          placeholder="Take a note..." 
//          rows="3" />
//         <button>Add</button>
//       </form>
//     </div>
//   );
// }

// function CreateArea() {
//   const [titleOfNewNote, setTitleOfNewNote] = useState("");
//   const [contentOfNewNote, setContentOfNewNote] = useState("");

//   function handleChange(event){
//     if (event.target.name === "title") {
//       setTitleOfNewNote(event.target.value)
//     } else if (event.target.name === "content") {
//       setContentOfNewNote(event.target.value)
//     }
//     // console.log(titleOfNewNote, contentOfNewNote);
//   }
//   return (
//     <div>
//       <form>
//         <input 
//         onChange={handleChange}
//         name="title" 
//         placeholder="Title" />
//         <textarea
//         onChange={handleChange}
//          name="content" 
//          placeholder="Take a note..." 
//          rows="3" />
//         <button>Add</button>
//       </form>
//     </div>
//   );
// }

// function CreateArea() {
//   return (
//     <div>
//       <form>
//         <input name="title" placeholder="Title" />
//         <textarea name="content" placeholder="Take a note..." rows="3" />
//         <button>Add</button>
//       </form>
//     </div>
//   );
// }

export default CreateArea;
