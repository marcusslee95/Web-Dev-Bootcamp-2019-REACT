import React, {useState} from "react";
import Header from "./Header";
import Footer from "./Footer";
import Note from "./Note";
import CreateArea from "./CreateArea";

function App() {
  const [notes, setNotes] = useState([]); 
  function addItem(note){
    // want to.add(note); to the array. Remember: since you're using useState Hook have to use it's setter to change it. Otherwise perhaps computer can't tell you made a change to it. 
    setNotes(function(prev){
      return [...prev,
        note
      ];
    });
    console.log(notes);
  }

  function deleteItem(indexOfSelectedNote){
    setNotes(
      notes.filter(
      function(currNote, currIndex){
        return currIndex !== indexOfSelectedNote; //returns a modified version of the notes where each element in it fulfills this condition
    }
    )
    );
  }

  return (
    <div>
      <Header />
      <CreateArea 
      functionToPassInFromParent={addItem}/>
      {notes.map(function(currNote, index) {//think i'll need to give each note a unique id so that when click it I can filter function for whatever doesn't have the sameID as the clicked note
      return <Note key={index} index={index} title={currNote.title} content={currNote.content} functionToPassInFromParent={deleteItem}/>;
      })}
      <Footer />
    </div>
  );
}


// function App() {
//   const [titleOfNewNote, setTitleOfNewNote] = useState("");
//   const [contentOfNewNote, setContentOfNewNote] = useState("");

//   function handleChange(event){
//     if (event.target.name === "title") {
//       setTitleOfNewNote(event.target.value)
//     } else if (event.target.name === "content") {
//       setContentOfNewNote(event.target.value)
//     }
//     // console.log(titleOfNewNote, contentOfNewNote);
//   }

//   return (
//     <div>
//       <Header />
//       <CreateArea 
//       inputChangeHandling={handleChange}/>
//       <Note key={1} 
//       title={titleOfNewNote}
//       content={contentOfNewNote} />
//       <Footer />
//     </div>
//   );
// }


// function App() {
//   return (
//     <div>
//       <Header />
//       <CreateArea />
//       <Note key={1} title="Note title" content="Note content" />
//       <Footer />
//     </div>
//   );
// }

export default App;
