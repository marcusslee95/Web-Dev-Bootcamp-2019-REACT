// let React = require("react");
import React from "react"
// let ReactDOM = require("react-dom");
import ReactDOM from "react-dom";
ReactDOM.render(<div>
  <h1>Hello World</h1><p>This is me</p>
  </div>, 
  document.getElementById("root"));